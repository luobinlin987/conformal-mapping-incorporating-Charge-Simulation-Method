#!/bin/bash

startTime=`date +%Y%m%d-%H:%M:%S`
startTime_s=`date +%s`

cd ~/researchpaper/paper12/code-resubmission/
# echo '******deep-1******'
# gfortran deep-1.f90 -L/usr/local/lib -llapack -lrefblas -o case
# ./case
# echo '******deep-2******'
# gfortran deep-2.f90 -L/usr/local/lib -llapack -lrefblas -o case
# ./case
# echo '******deep-3******'
# gfortran deep-3.f90 -L/usr/local/lib -llapack -lrefblas -o case
# ./case
# echo '******deep-4******'
# gfortran deep-4.f90 -L/usr/local/lib -llapack -lrefblas -o case
# ./case
# echo '******shallow-1******'
# gfortran shallow-1.f90 -L/usr/local/lib -llapack -lrefblas -o case
# ./case
# echo '******shallow-2******'
# gfortran shallow-2.f90 -L/usr/local/lib -llapack -lrefblas -o case
# ./case
# echo '******shallow-3******'
# gfortran shallow-3.f90 -L/usr/local/lib -llapack -lrefblas -o case
# ./case
# echo '******shallow-4******'
# gfortran shallow-4.f90 -L/usr/local/lib -llapack -lrefblas -o case
# ./case
# echo '******shallow-case-verification******'
# gfortran ./Section\ 7.2/shallow-case-verification.f90 -L/usr/local/lib -llapack -lrefblas -o case
# ./case
# echo '******shallow-case-fortified******'
# gfortran ./Section\ 7.3/shallow-case-fortified.f90 -L/usr/local/lib -llapack -lrefblas -o case
# ./case
# echo '******shallow-case-fortified-base******'
# gfortran ./Section\ 7.3/shallow-case-fortified-base.f90 -L/usr/local/lib -llapack -lrefblas -o case
# ./case

cd ~/researchpaper/paper12/gnuplot-resubmission/
# gnuplot deep-1.gp
# cp deep-1.pdf /home/lin/researchpaper/paper12/NAG-resubmission/manuscript/fig5.pdf
# gnuplot deep-234.gp
# cp deep-234.pdf /home/lin/researchpaper/paper12/NAG-resubmission/manuscript/fig6.pdf
# gnuplot shallow-1.gp
# cp shallow-1.pdf /home/lin/researchpaper/paper12/NAG-resubmission/manuscript/fig7.pdf
# gnuplot shallow-234.gp
# cp shallow-234.pdf /home/lin/researchpaper/paper12/NAG-resubmission/manuscript/fig8.pdf
# gnuplot shallow-case-alpha.gp
# gio open shallow-case-alpha.pdf
# cp shallow-case-alpha.pdf /home/lin/researchpaper/paper12/NAG-resubmission/manuscript/fig12.pdf
# gnuplot shallow-case-1.gp
# gio open shallow-case-1.pdf
# cp shallow-case-1.pdf /home/lin/researchpaper/paper12/NAG-resubmission/manuscript/fig13.pdf
# gnuplot shallow-case-fortified-alpha.gp
# gio open shallow-case-fortified-alpha.pdf
# cp shallow-case-fortified-alpha.pdf /home/lin/researchpaper/paper12/NAG-resubmission/manuscript/fig14.pdf
# gnuplot shallow-case-fortified-1.gp
# gio open shallow-case-fortified-1.pdf
# cp shallow-case-fortified-1.pdf /home/lin/researchpaper/paper12/NAG-resubmission/manuscript/fig15.pdf

endTime=`date +%Y%m%d-%H:%M:%S`
endTime_s=`date +%s`

sumTime=$[ $endTime_s - $startTime_s ]

echo "$startTime ---> $endTime" "Total:$sumTime seconds"
